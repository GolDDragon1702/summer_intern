import os
import json
import jiwer
from collections import defaultdict

reference_dir = "/storage/intern_hcm/longph/results/reference/test"
results_dir = "/storage/intern_hcm/longph/results/results/test"

os.makedirs(reference_dir, exist_ok=True)
os.makedirs(results_dir, exist_ok=True)

all_reference_texts = []
all_result_texts = []

mismatch_counts = defaultdict(int)

for filename in os.listdir(reference_dir):
    if filename.endswith(".json"):
        reference_file = os.path.join(reference_dir, filename)
        result_file = os.path.join(results_dir, filename)
        
        if os.path.exists(result_file):
            with open(reference_file, 'r', encoding='utf-8') as ref_f:
                reference_data = json.load(ref_f)
            
            with open(result_file, 'r', encoding='utf-8') as res_f:
                result_data = json.load(res_f)
            
            for key in reference_data:
                reference_text = reference_data.get(key, "")
                result_text = result_data.get(key, "")
                
                all_reference_texts.append(reference_text)
                all_result_texts.append(result_text)
                
                cer = jiwer.cer(reference_text, result_text)
                wer = jiwer.wer(reference_text, result_text)
                match = "Match" if reference_text == result_text else "Mismatch"
                
                if match == "Mismatch":
                    mismatch_counts[key] += 1

        else:
            print(f"Result file {filename} not found in {results_dir}")

if all_reference_texts and all_result_texts:
    combined_reference_text = " ".join(all_reference_texts)
    combined_result_text = " ".join(all_result_texts)
    
    overall_cer = jiwer.cer(combined_reference_text, combined_result_text)
    overall_wer = jiwer.wer(combined_reference_text, combined_result_text)
    overall_wip = jiwer.wip(combined_reference_text, combined_result_text)
    
    print(f"Overall CER: {overall_cer:.2f}")
    print(f"Overall WER: {overall_wer:.2f}")
    print(f"Overall WIP: {overall_wip:.2f}")
else:
    print("No text data found to compare.")

print("\nMismatch Summary:")
for key, count in mismatch_counts.items():
    print(f"{key}: {count} mismatches")
